package com.example.sohailrajpoot.navigationdrawer;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
private DrawerLayout nDrawerlayout;
    private ActionBarDrawerToggle actionbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nDrawerlayout= (DrawerLayout) findViewById(R.id.drawer);
        actionbar=new ActionBarDrawerToggle(this,nDrawerlayout,R.string.open,R.string.close);
        nDrawerlayout.addDrawerListener(actionbar);
        actionbar.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if(actionbar.onOptionsItemSelected(item))
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
